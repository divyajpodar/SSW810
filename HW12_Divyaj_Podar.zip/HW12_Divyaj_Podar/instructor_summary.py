"""importing modules"""
from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

@app.route('/instructors')

def instructor_summary():
    """creating a py file to be used by flask"""
    db_path = '/Users/divyaj_podar/Desktop/ssw810/HW12_Divyaj_Podar/database.db'

    try:
        db = sqlite3.connect(db_path)
    except sqlite3.OperationalError:
        return f"Error: {db_path} cannot be opened"
    else:

        query = """SELECT i.CWID, i.Name, i.Dept, g.Course, COUNT(g.StudentCWID) AS Students
                    FROM instructors AS i
                    JOIN grades AS g
                    ON i.CWID = g.InstructorCWID
                    GROUP BY g.Course, g.InstructorCWID
                    ORDER BY i.CWID DESC, COUNT(g.StudentCWID) DESC"""

        data = [{'cwid': cwid, "name": name, "dept": dept, "course": course, "students": students} 
                for cwid, name, dept, course, students in db.execute(query)]

        db.close()

        return render_template("instructor_summary.html", 
                                title="Stevens Repository", 
                                table_title="Number of students by course and instructor", 
                                instructors=data)

app.run()